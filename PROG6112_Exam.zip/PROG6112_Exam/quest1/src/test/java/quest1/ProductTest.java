package quest1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

// Q.1.4 - unit tests for the Product class, using the sample data from the brief
public class ProductTest {

    // Same product names and sales figures as the sample screenshot
    private final String[] names = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    private final int[][] sales = {
        {25, 18, 20},  // Cozy Nights Monarch  = 63
        {15, 10, 12},  // Restonic Barbados    = 37
        {18, 15, 20}   // Sealy Phuket         = 53
    };

    // Unit Test 1: total of all values should be 63 + 37 + 53 = 153
    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(names, sales);   // Arrange
        int actual = product.GetTotalProductsSold();   // Act
        assertEquals(153, actual);                     // Assert
    }

    // Unit Test 2: average = 153 / 9 values = 17
    // The 0.001 is the allowed difference, needed when comparing doubles
    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(names, sales);   // Arrange
        double actual = product.GetAverageProductSold(); // Act
        assertEquals(17.0, actual, 0.001);             // Assert
    }
}