package q2;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

// Q.2.6 - unit tests for the ProductCalculations class
// Sample from the brief: price R3500 -> VAT 525, commission 175, total 4200
public class ProductCalculationsTest {

    private static final double DELTA = 0.001; // allowed difference when comparing doubles

    // Unit Test 1: VAT is 15% of the price, so 3500 x 0.15 = 525
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500); // Arrange
        double actual = calc.GetVat();                            // Act
        assertEquals(525.0, actual, DELTA);                       // Assert
    }

    // Unit Test 2: total = price + VAT + commission = 3500 + 525 + 175 = 4200
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500); // Arrange
        double actual = calc.GetTotal();                          // Act
        assertEquals(4200.0, actual, DELTA);                      // Assert
    }
}